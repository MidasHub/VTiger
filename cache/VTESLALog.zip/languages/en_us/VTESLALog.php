<?php

/* ********************************************************************************
 * The content of this file is subject to the Notifications ("License");
 * You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is VTExperts.com
 * Portions created by VTExperts.com. are Copyright(C) VTExperts.com.
 * All Rights Reserved.
 * ****************************************************************************** */

$languageStrings = Array(
    'LBL_POLICY_ID' => 'Policy ID',
    'LBL_RELATED_TO' => 'Related To',
    'LBL_POLICY_NAME' => 'Policy Name',
    'LBL_ACTION_NAME' => 'Alert Name',
    'LBL_TRIGGER' => 'Trigger',
    'LBL_TYPE' => 'Type',
    'SINGLE_VTESLALog' => 'SLA Log',
    'LBL_DETAIL_INFORMATION' => 'Information Detail',
    'LBL_TIME_REMAINING' => 'Time Remaining',
    'LBL_TIME_ELAPSED' => 'Time Elapsed',
    //picklist

    'Email' => 'Email',
);

?>
